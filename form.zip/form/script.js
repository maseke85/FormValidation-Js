let nameError = document.getElementById('name-error');
let emailError = document.getElementById('email-error');
let passwordError = document.getElementById('password-error');
let submitError = document.getElementById('submit-error');

function validateName(){
    let name = document.getElementById('fname').value;

    if(name.length == 0){
        nameError.innerHTML = 'Name is required';
        return false;
    }
    if(!name.match(/^[A-Za-z]*\s{1}[A-Za-z]*$/)){
        nameError.innerHTML = 'Enter full name';
        return false;
    }
    else{
        nameError.innerHTML = '<i class="fa-solid fa-circle-check"></i>';
        return true;
    }
}

function validateEmail(){
    let email = document.getElementById('mail').value;

    if(email.length == 0){
        emailError.innerHTML = 'Email is required';
        return false;
    }
    if(!email.match(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)){
        emailError.innerHTML = 'Invalid email';
        return false;
    }
    else{
        emailError.innerHTML = '<i class="fa-solid fa-circle-check"></i>';
        return true;
    }

}

function validatePassword(){
    let password = document.getElementById('password').value;

    if(password.length == 0){
        passwordError.innerHTML = 'Password is required';
        return false;
    }
    if(password.length < 8){
        passwordError.innerHTML = 'Password must be 8 chars long';
        return false;
    }
    else{
        passwordError.innerHTML = '<i class="fa-solid fa-circle-check"></i>';
        return true;
    }
}

function validateForm(){
    if(!validateName() || !validateEmail() || !validatePassword()){
        submitError.innerHTML = 'Please fix some error(s)';
        submitError.style.display = 'block';
        setTimeout(function(){submitError.style.display = 'none';},3000);
         return false;
     }
}